package com.example.awsspringdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsSpringDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsSpringDemoApplication.class, args);
	}

}
