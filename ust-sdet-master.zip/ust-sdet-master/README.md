# UST Training

    Getting started on Java
    1. Install JDK 11 & Eclipse
    2. Create a Java Project on Eclipse
    3. Create a "Hello world" program

    Spring Boot Application
    1. Start spring io 
    2. Deps: Web, Data, Devtools and Mysql
    3. Controllers, Repos, Entities
    4. @CrossOrigin