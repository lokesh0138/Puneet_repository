package com.ust.day2;

public interface Movement {

	void move();
	void stop();
}
