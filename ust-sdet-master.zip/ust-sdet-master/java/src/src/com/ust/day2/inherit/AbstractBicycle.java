package com.ust.day2.inherit;

public abstract class AbstractBicycle implements Bicycle{


	public void peddle() {
		System.out.println("Peddling..");
	}

}
