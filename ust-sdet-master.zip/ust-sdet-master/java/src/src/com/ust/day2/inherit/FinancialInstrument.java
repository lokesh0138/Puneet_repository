package com.ust.day2.inherit;

public interface FinancialInstrument {
	
	void sell(int quantity);
	void buy(int quantity);

}
