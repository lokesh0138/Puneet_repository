package com.ust.day2.inherit;

public interface Bicycle {
	
	void applyBrakes(int decrement);
	void speedUp(int increment);
//	void peddle();

}
