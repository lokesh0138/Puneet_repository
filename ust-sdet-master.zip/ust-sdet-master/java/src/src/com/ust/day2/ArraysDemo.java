package com.ust.day2;

public class ArraysDemo {

    public static void main(String[] args) {
        // int priyaMarks = 34;
        // int []marks = new int[4];

        // marks[0] = 23;
        // marks[1] = 13;
        // marks[2] = 43;
        // marks[3] = 53;

        int marks[] = {34,34,334,45,445};

        // marks[5] = 63;

        // for(int i=0; i< marks.length; i++){
        //     System.out.println(marks[i]);
        // }

        // enhanced-for loop
        for(int mark: marks){
            System.out.println(mark);
        }




    }
    
}
