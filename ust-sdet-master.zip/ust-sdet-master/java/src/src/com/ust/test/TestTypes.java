package com.ust.test;

import com.ust.Employee;

public class TestTypes {

	public static void main(String[] args) {
		byte age = -128;
		
		long l = 3434343335545433l;
		
		Employee e = new Employee(23, "Test", 34343);
		
		char c = 's';
		System.out.println(age);

	}

}
