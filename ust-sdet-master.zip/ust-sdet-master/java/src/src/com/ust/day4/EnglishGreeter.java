package com.ust.day4;

public class EnglishGreeter implements Greeter {

	@Override
	public void sayHello() {
		System.out.println("Hello!!");
		
	}

}
