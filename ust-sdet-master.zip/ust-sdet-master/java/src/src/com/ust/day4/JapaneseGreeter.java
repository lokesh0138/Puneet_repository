package com.ust.day4;

public class JapaneseGreeter implements Greeter {
	@Override
	public void sayHello() {
		System.out.println("Konicchiwwa!!");
		
	}
}
