package com.ust.day4;

@FunctionalInterface
public interface Greeter {
	void sayHello();
}
