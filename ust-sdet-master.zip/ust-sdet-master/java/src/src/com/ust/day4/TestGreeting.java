package com.ust.day4;

public class TestGreeting {

	public static void main(String[] args) {
//		Greeter greeter = new JapaneseGreeter();
//		greeter.sayHello();
//		
//		
//		// anonymous class
//		Greeter frenchGreeter = new Greeter() {
//			@Override
//			public void sayHello() {
//				System.out.println("Bonjour!!");
//				
//			}	
//		};
//		frenchGreeter.sayHello();
		
		
		// lamdas
//		Greeter hindiGreeter = (str)-> System.out.println(str);
//		hindiGreeter.sayHello("Namaste!!");

	}

}
