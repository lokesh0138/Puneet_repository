package com.ust;

public class LoopsDemo {

	public static void main(String[] args) {
	
		int age = 7;
		
//		if(age > 18) {
//			System.out.println("Eligible to vote");
//		}
//		else if(age == 18) {
//			System.out.println("First voting");
//		}
//		else {
//			System.out.println("Not eligible");
//		}
//		
		
//		switch(age) {
//			case 36: System.out.println("Eligible to vote");
//						break;
//			case 18: System.out.println("First voting");
//						break;
//			case 12: System.out.println("Not eligible");
//						break;
//			default: System.out.println("Not sure");
//		}
		int i = 1;
		int j = 34;
		
		System.out.println(!(i == j));
//		
//		while(i<10) {
//			System.out.println("Do something");
//			i++;
//		}
		
//		for(int i=1; i<=10; i++) {
//			System.out.println("Do it for loop");
//		}
//		
//		do {
//			System.out.println("Do something");
//			i++;
//		}while(i<10);
//		
//		for(;;) {
//			System.out.println("Goes infinitely");
//		}
//		
		
		
//		System.out.println("Allz well that ends well");

	}

}
