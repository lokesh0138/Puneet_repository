package com.tkhts.order.bo;

public class Test04_EclemmaCodeCoverage {

}
