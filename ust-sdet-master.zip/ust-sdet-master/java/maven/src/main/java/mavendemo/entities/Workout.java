package mavendemo.entities;

import java.util.Date;

public class Workout {
	
	int id;
//	Jogging for 10 mins
	String title;
//	Good for health and easy 
	String desc;
//	10 calories
	int cbpm;
//	start time
	Date startTime;
//	end time
	Date endTime;
	

}
