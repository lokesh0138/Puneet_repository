package mavendemo;

public class FundsTransferService {
	
	public void payment(int accountTo, int accountFrom, double amount) {
//		1.  balance enquire
//		2. permissible limits of transfer
//		3. debit the from account
//		4. credit to account
//		5. gl entry
//		6. transaction log
		
		
//		boolean success = SMSGateway. send(String message, int phonenumber)
//		boolean success = DummySMSGateway.send(String message, int phonenumber)
//		boolean success = true;
//		Fakes, Stubs and Mocks
//		SMSGateway.send("Your account successfully debited with Rs. 50000", 9987655432);
//		7. sms success/failure
		
		
	}

}
