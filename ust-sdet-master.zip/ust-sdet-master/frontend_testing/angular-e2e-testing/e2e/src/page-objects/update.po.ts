import { Main } from "./main.po";

export class Update extends Main{
    
}