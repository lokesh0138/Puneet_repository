    Testing using Karma
        # Install Karma:
        $ npm install karma --save-dev

        # Install plugins that your project needs:
        $ npm install karma-jasmine karma-chrome-launcher jasmine-core --save-dev

        $ npm install -g karma-cli

        karma init --> Generate karma.conf.js and change the files section

        karma start --> Run test cases on the browser


        For coverage and html reports 

        # npm install --save-dev karma-htmlfile-reporter karma-coverage