
console.log('Hello NodeJS!!')

const sum = (x,y) => x+y;

console.log(sum(2,3));