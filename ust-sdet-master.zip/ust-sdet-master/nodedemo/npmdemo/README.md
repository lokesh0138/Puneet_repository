    #NODEJS ENV
        - NPM : Node Package Manager for installing third party packages
        - npm init: generating package.json
        - npm install <package_name>: installing packages/dependencies
        - npm install : read packages from package.json and install them