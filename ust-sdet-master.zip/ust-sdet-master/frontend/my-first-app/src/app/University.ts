
export class University{
    constructor(public country: string, public name: string, public alpha_two_code: string, public stateProvince: string, public  domains: Array<string>,public web_pages: Array<string>){

    }
}