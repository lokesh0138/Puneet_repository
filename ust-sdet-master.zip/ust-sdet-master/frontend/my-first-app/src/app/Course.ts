export class Course{
    constructor(public id: number, public title: string, public summary: string ){

    }
}