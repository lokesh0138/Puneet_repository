package mavendemo.exception;

public class ServiceException extends Exception {

}
