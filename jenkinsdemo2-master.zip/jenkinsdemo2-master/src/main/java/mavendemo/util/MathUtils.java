package mavendemo.util;



public class MathUtils {
	
	// return square of function
	public static int square(final int number){
		return number * number;
	}
	
	// loan calculation

}
